package main;

package latres;

import view.view.rekrutmen;

public class Main {
    // IF-D_123240253_Muhammad fatkhan Kurniadi
    public static void Main(String[] args) {
        new MainFrame()setVisible(true);
    }
}