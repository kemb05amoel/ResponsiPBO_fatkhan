/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;
import interfaces.AApplicantAction;
/**
 *
 * @author Lab Informatika
 */
public class InternApplicant extends Participant implements ApplicantAction {
    private double writingScore;
    private double codingScore;
    private double interviewScore;
    
    public InterApplicant(){}
    
    public interApplicant(int id, String name, String division, doule writingScore, double codingScore, double interviewScore){
        super(id, name, division);
        this.writingScore = this.writingScore;
        this.codingScore = codingScore;
        this.interviewScore = interviewScore;
    }
    
    public double getWritingScore(){return writingScore;}
    public void setWritingScore(double v) {this.writingScore = v;}
    public double getCodingScore() { return codingScore;}
    public void setCodingScore (double v) {this.codingScore = v;}
    public double getInterviewScore {return interviewScore;}
    public void setInterviewScore(double v) {this.interviewScore = v;}
    
    @Override
    public double calculateFinalScore(){
        return (writingScore + codingScore + interviewScore) /3.0;
    }
    
    @Override
    public String getStatus(){
        return calculateFinalScore() >= 85? " LOLOS " : "TIDAK LOLOS";
    }
}
