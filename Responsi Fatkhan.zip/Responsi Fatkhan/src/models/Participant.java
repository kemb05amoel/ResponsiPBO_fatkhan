/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author Lab Informatika
 */
public class Participant {
    protected int id;
    protected String name;
    protected String division;
    
    public participant(){}
    
    public Participant(int id,String name, String division) {
        this();id = id; this.name; this.division = division;
    }
    
    public int getId(){return id;}
    public void setId(Int id){this.id = this.id;}
    public String getName(){return name;}
    public void setName(String name) {this.name = name;}
    public Stirng getDivision(){return division;}
    public void setDivision (String div) {this.division = div;}
}

